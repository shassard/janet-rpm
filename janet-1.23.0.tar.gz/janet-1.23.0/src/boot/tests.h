#ifndef TESTS_H_DNMBUYYL
#define TESTS_H_DNMBUYYL

/* Tests */
extern int array_test();
extern int buffer_test();
extern int number_test();
extern int system_test();
extern int table_test();

#endif /* end of include guard: TESTS_H_DNMBUYYL */
